package com.example.Mini.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Mini.model.Publication;
import com.example.Mini.repository.PublicationRepository;
import com.example.Mini.web.dto.PublicationDto;

@Service
public class PublicationServiceImpl implements PublicationService {

    @Autowired
    private PublicationRepository publicationRepository;

    @Override
    public List<Publication> findAll() {
        return publicationRepository.findAll();
    }

    @Override
    public void save(PublicationDto publicationDto) {
        Publication publication = new Publication();
        publication.setTitle(publicationDto.getTitle());
        publication.setAuthor(publicationDto.getAuthor());
        publication.setJournal(publicationDto.getJournal());
        publication.setYear(publicationDto.getYear());
        publicationRepository.save(publication);
    }
}
