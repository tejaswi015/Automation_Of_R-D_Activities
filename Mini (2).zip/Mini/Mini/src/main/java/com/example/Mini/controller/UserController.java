package com.example.Mini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.Mini.model.User;
import com.example.Mini.service.UserService;
import com.example.Mini.service.UserServiceImpl;
import com.example.Mini.service.PublicationService;
import com.example.Mini.web.dto.PublicationDto;
import com.example.Mini.web.dto.UserDto;

@Controller
public class UserController {

    @Autowired
    private UserServiceImpl userServiceImpl;

    @Autowired
    private UserService userService;

    @Autowired
    private PublicationService publicationService;

    // --- User Registration and Login ---

    @GetMapping("/register")
    public String showFacultyRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "register";  // Faculty registration page
    }

    @PostMapping("/register")
    public String saveUser(@ModelAttribute("user") UserDto userDto, Model model) {
        userService.save(userDto);
        model.addAttribute("message", "Registered Successfully!");
        return "redirect:/loginfaculty";  // Redirect to login page after registration
    }

    @GetMapping("/loginfaculty")
    public String showFacultyLoginForm(Model model) {
        model.addAttribute("user", new User());
        return "loginfaculty";  // Faculty login page
    }

    @PostMapping("/loginfaculty")
    public String loginFaculty(@ModelAttribute UserDto userDto, Model model) {
        User loggedInUser = userDto.findByEmail(userDto.getEmail());
        if (loggedInUser != null && userDto.checkPassword(userDto.getPassword(), userDto.getPassword())) {
            model.addAttribute("user", loggedInUser);
            return "redirect:/index";  // Redirect to home page after login
        } else {
            return "redirect:/loginfaculty?error=true";  // Redirect with error if login fails
        }
    }

    @GetMapping("/ten")
    public String showTop10Profiles(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        boolean isUserLoggedIn = authentication != null && authentication.isAuthenticated()
                && authentication.getAuthorities().stream()
                    .anyMatch(role -> role.getAuthority().equals("USER"));
        model.addAttribute("userLoggedIn", isUserLoggedIn);
        return "ten";  // Top 10 profiles page
    }

    // --- Publications Section ---

    // Display the publications list
    @GetMapping("/pub")
    public String showPublicationsPage(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        boolean isUserLoggedIn = authentication != null && authentication.isAuthenticated();

        model.addAttribute("userLoggedIn", isUserLoggedIn);  // Pass user login status to view
        model.addAttribute("publications", publicationService.findAll());  // Fetch and add publications to the model

        return "pub";  // Return the publications view (pub.html)
    }

    // Show form to add a new publication (only if user is logged in)
    @GetMapping("/publications/new")
    public String showNewPublicationForm(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/loginfaculty";  // Redirect to login if not authenticated
        }

        model.addAttribute("publication", new PublicationDto());  // Pass an empty PublicationDto to the form
        return "new_publication";  // Return the form view to add a new publication
    }

    // Save new publication to the database (only if user is logged in)
    @PostMapping("/publications/save")
    public String savePublication(@ModelAttribute("publication") PublicationDto publicationDto) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/loginfaculty";  // Redirect to login if not authenticated
        }

        publicationService.save(publicationDto);  // Save the new publication to the database
        return "redirect:/pub";  // Redirect back to the publications list after saving
    }
}
