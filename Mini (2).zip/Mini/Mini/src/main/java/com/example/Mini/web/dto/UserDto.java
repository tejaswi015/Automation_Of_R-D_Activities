package com.example.Mini.web.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;


import com.example.Mini.model.User;
import com.example.Mini.repository.UserRepository;

public class UserDto {
	
	@Autowired
    private PasswordEncoder passwordEncoder;
    
	private final UserRepository userRepository;

    public UserDto(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
	private String email;
	private String Password;
	private String role;
	private String fullname;
	public UserDto(String email, String password, String role, String fullname) {
		super();
		this.userRepository = null;
		this.email = email;
		Password = password;
		this.role = role;
		this.fullname = fullname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	
	public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public boolean checkPassword(String rawPassword, String encodedPassword) {
        return passwordEncoder.matches(rawPassword, encodedPassword);
    }


}
