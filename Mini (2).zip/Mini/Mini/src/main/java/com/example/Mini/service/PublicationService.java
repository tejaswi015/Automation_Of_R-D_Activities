package com.example.Mini.service;

import java.util.List;
import com.example.Mini.model.Publication;
import com.example.Mini.web.dto.PublicationDto;

public interface PublicationService {
    List<Publication> findAll();
    void save(PublicationDto publicationDto);
}
